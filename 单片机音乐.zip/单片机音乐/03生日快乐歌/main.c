#include <REGX52.H>
#include "Delay.h"
#include "Timer0.h"


sbit Buzzer=P2^5;//�������˿ڶ���


#define SPEED	500  //�����ٶ�

#define P	0
#define L1	1
#define L1_	2
#define L2	3
#define L2_	4
#define L3	5
#define L4	6
#define L4_	7
#define L5	8
#define L5_	9
#define L6	10
#define L6_	11
#define L7	12
#define M1	13
#define M1_	14
#define M2	15
#define M2_	16
#define M3	17
#define M4	18
#define M4_	19
#define M5	20
#define M5_	21
#define M6	22
#define M6_	23
#define M7	24
#define H1	25
#define H1_	26
#define H2	27
#define H2_	28
#define H3	29
#define H4	30
#define H4_	31
#define H5	32
#define H5_	33
#define H6	34
#define H6_	35
#define H7	36


unsigned int FreqTable[]={
	0,
	63628,63731,63835,63928,64021,64103,64185,64260,64331,64400,64463,64528,
	64580,64633,64684,64732,64777,64820,64860,64898,64934,64968,65000,65030,
	65058,65085,65110,65134,65157,65178,65198,65217,65235,65252,65268,65283,
};



unsigned char code Music0[]={
  //1
	P,4,
	M5,2+2,
	M5,1,
	
	//2
	M6,4,
	M5,4,
	H1,4,
	
	//3
	M7,4+4,
	M5,2+2,
	M5,1,
	
	//4
	M6,4,
	M5,4,
	H2,4,
	
	//5
	H1,4+4,
	M5,2+2,
	M5,1,
	
	//6
	H5,4,
	H3,4,
	H1,4,
	
	//7
	M7,4,
	M6,4,
	H4,2+2,
	H4,1,
	
	//8
	H3,4,
	H1,4,
	H2,4,
	
	//9
	H1,4+4,
	M5,2+2,
	M5,1,
	
	//10
	M6,4,
	M5,4,
	H1,4,
	
	//11
	M7,4+4,
	M5,2+2,
	M5,1,
	
	//12
	M6,4,
	M5,4,
	H2,4,
	
	//13
	H1,4+4,
	M5,2+2,
	M5,1,
	
	//14
	H5,4,
	H3,4,
	H1,4,
	
	//15
	M7,4,
	M6,4,
	H4,2+2,
	H4,1,
	
	//16
	H3,4,
	H1,4,
	H2,4,
	
	//17
	H1,2+4,
	P,4,
	
	
	0xFF
};



	
	
	
unsigned char FreqSelect,MusicSelect;

void main()
{
	Timer0_Init();
	while(1)
	{
		if(Music0[MusicSelect]!=0xFF)	
		{
			FreqSelect=Music0[MusicSelect];	
			MusicSelect++;
			Delay(SPEED/4*Music0[MusicSelect]);	
			MusicSelect++;
			TR0=0;
			Delay(5);	
			TR0=1;
		}
		else	
		{
			TR0=0;
			while(1);
		}
//		if(MusicSelect==112*2){
//		   MusicSelect=0;
//			 break;
//		}
	}
	
	
}	

void Timer0_Routine() interrupt 1
{
	if(FreqTable[FreqSelect])	
	{
		
		TL0 = FreqTable[FreqSelect]%256;		
		TH0 = FreqTable[FreqSelect]/256;	
		Buzzer=!Buzzer;	
	}
}
