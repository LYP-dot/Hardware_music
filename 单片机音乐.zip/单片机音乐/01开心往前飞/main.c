#include <REGX52.H>
#include "Delay.h"
#include "Timer0.h"


sbit Buzzer=P2^5;//�������˿ڶ���


#define SPEED	340  //�����ٶ�

#define P	0
#define L1	1
#define L1_	2
#define L2	3
#define L2_	4
#define L3	5
#define L4	6
#define L4_	7
#define L5	8
#define L5_	9
#define L6	10
#define L6_	11
#define L7	12
#define M1	13
#define M1_	14
#define M2	15
#define M2_	16
#define M3	17
#define M4	18
#define M4_	19
#define M5	20
#define M5_	21
#define M6	22
#define M6_	23
#define M7	24
#define H1	25
#define H1_	26
#define H2	27
#define H2_	28
#define H3	29
#define H4	30
#define H4_	31
#define H5	32
#define H5_	33
#define H6	34
#define H6_	35
#define H7	36


unsigned int FreqTable[]={
	0,
	63628,63731,63835,63928,64021,64103,64185,64260,64331,64400,64463,64528,
	64580,64633,64684,64732,64777,64820,64860,64898,64934,64968,65000,65030,
	65058,65085,65110,65134,65157,65178,65198,65217,65235,65252,65268,65283,
};



unsigned char code Music0[]={
	//1
	M5,4,
	M5,4,
	M5_,4,
	M5_,4,
	
	//2
	M6,2,
	M7,4,
	H1,2+2,
	M5,2,
	M6,2,
	H1,2+4+4,
	
	//3
	H2,2,
	H2,2,
	M6,2,
	H1,2+4+4,
	
	//4
	P,2,
	H1,2,
	
	//5
	H3,4,
	H3,4,
	H2,2,
	H1,4,
	H3,2+4,
	
	//6
	H3,4,
	H2,2,
	H1,4,
	H1,2,
	
	//7
	H3,4,
	H3,4,
	H2,2,
	H1,4,
	H3,2+2,
	
	//8
	H1,2,
	H2,2,
	H1,2,
	H2,2,
	H1,2,
	H1,2,
	H1,2,
	
	//9
	M6,2,
	H1,2,
	H1,4,
	P,4,
	
	//10
	P,4,
	H2,2,
	H1,2,
	
	//11
	M5,2,
	H1,2,
	H1,4,
	P,4,
	
	//12
	P,2,
	M5,2,
	M6,2,
	H1,2,
	
	//13
	H3,4,
	H3,4,
	H2,2,
	H1,4,
	H3,2+4,
	
	//14
	H3,4,
	H2,2,
	H1,4,
	H1,2,
	
	//15
	H3,4,
	H3,4,
	H2,2,
	H1,4,
	H3,2+2,
	
	//16
	H1,2,
	H2,2,
	H1,2,
	H2,2,
	H1,2,
	H1,2,
	H1,2,
	
	//17
	M6,2,
	H1,2,
	H1,4,
	P,4,
	
	//18
	P,2,
	H1,2,
	H2,2,
	H1,2,
	
	//19
	H3,4,
	H3,4,
	H2,2,
	H1,4,
	H3,2+4,
	
	//20 89
	H3,4,
	H2,4,
	H1,4,
	
	//21
	H2,4,
	H3,2,
	H1,4,
	M6,2+4,
	
	//22
	H2,4,
	H3,2,
	H1,2+4+4,
	
	//23
	H2,4,
	H3,2,
	H1,4,
	M5,2+4,
	
	//24 103
	M7,4+2,
	H6,2+4,
	
	//25
	M5,2,
	M5,4,
	M5,2+2,
	M3,2,
	M4,2,
	M3,2,
	
	//26
	M5,2,
	M5,4,
	M5,2+4+4,
	

	
};

unsigned char code Music1[]={
  //27
	M5_,2,
	M5_,2,
	M5_,2,
	M5_,2,
	M6_,2,
	M5_,2,
	M5_,2,
	M4,2,
	
	//28
	M5,4+4,
	M3,4,
	M4,4,
	
	//29
	M5,4,
	M5,4,
	M5,2,
	M4,2,
	M3,2,
	M3,2+4,
	
	//30
	M3,4,
	M4,2,
	M5,2,
	M5_,2,
	M6,2+4,
	
	//31
	M6,4,
	M6,2,
	M7,2,
	H1,2,
	H1,2+4+4,
	
	//32
	H1,2,
	H2,2,
	H3,2,
	H1,2+4+4+4,
	
	//33
	H2,2,
	H1,2,
	
	//34
	H3,4,
	H3,4,
	H2,2,
	H1,4,
	H5,2+4,
	
	//35
	M3,2,
	M4,2,
	M3,2,
	M2,2+4+4,
	
	//36
	M3,4,
	M4,4,
	
	//37
	M5,4,
	M5,4,
	M5,2,
	M4,2,
	M3,2,
	M3,2+4,
	
	//38
	M3,4,
	M4,2,
	M5,2,
	M5_,2,
	M6,2+4,
	
	//39
	M6,4,
	M6,2,
	M7,2,
	H1,2,
	H1,2+4+4,
	
	//40
	H1,2,
	H2,2,
	H3,2,
	H1,2+4+4,
	
	//41
	P,2,
	H1,2,
	H2,2,
	H1,2,
	
	//42
	H3,4,
	H3,4,
	H3,2,
	H2,4,
	H1,2+4,
	
  0xFF
	
};

	
	
	
unsigned char FreqSelect,MusicSelect;

void main()
{
	Timer0_Init();
	while(1)
	{
		if(Music0[MusicSelect]!=0xFF)	
		{
			FreqSelect=Music0[MusicSelect];	
			MusicSelect++;
			Delay(SPEED/4*Music0[MusicSelect]);	
			MusicSelect++;
			TR0=0;
			Delay(5);	
			TR0=1;
		}
		else	
		{
			TR0=0;
			while(1);
		}
		if(MusicSelect==111*2){
		   MusicSelect=0;
			 break;
		}
	}
	
	while(1)
	{
		if(Music1[MusicSelect]!=0xFF)	
		{
			FreqSelect=Music1[MusicSelect];	
			MusicSelect++;
			Delay(SPEED/4*Music1[MusicSelect]);	
			MusicSelect++;
			TR0=0;
			Delay(5);	
			TR0=1;
		}
		else	
		{
			TR0=0;
			while(1);
		}
//		if(MusicSelect==112*2){
//		   MusicSelect=0;
//			 break;
//		}
	}
	
}	

void Timer0_Routine() interrupt 1
{
	if(FreqTable[FreqSelect])	
	{
		
		TL0 = FreqTable[FreqSelect]%256;		
		TH0 = FreqTable[FreqSelect]/256;	
		Buzzer=!Buzzer;	
	}
}
