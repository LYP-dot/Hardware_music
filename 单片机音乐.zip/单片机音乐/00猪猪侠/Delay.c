void Delay(int x)	
{
	unsigned char i, j;
  while(x){
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
		x--;
	}
}