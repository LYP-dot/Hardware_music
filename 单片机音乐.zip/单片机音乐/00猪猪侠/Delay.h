#ifndef _DELAY_H_
#define _DELAY_H_

void Delay(int x);

#endif