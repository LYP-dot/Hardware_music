#include <REGX52.H>


//定时器0初始化  1毫秒12.000MHZ
void Timer0_Init()	
{
		TMOD &= 0xF0;		//设置定时器模式
		TMOD |= 0x01;		//设置定时器模式
		TL0 = 0x18;		//设置定时初值
		TH0 = 0xFC;		//设置定时初值
		TF0 = 0;		//清除TF0标志
		TR0 = 1;		//定时器0开始计时
		ET0=1;
		EA=1;
		PT0=0;
}

/*
void Timer0_Routine() interrupt 1{
		static int T0Count;
		TL0 = 0x18;		//设置定时初值
		TH0 = 0xFC;
		T0Count++;
		if(T0Count>=1000){
				T0Count=0;
				P2_0=~P2_0;
		}
		
}
定时器中断函数模板，使用复制到main.c即可
*/